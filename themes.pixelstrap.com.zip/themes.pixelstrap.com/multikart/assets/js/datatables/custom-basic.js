$(document).ready(function() {
    $('product-list').DataTable();
    // Basic table example
    $('#basic-1').DataTable();
});
